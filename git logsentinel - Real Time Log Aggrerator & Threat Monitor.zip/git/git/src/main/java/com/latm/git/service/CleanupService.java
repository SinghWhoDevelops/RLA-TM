package com.latm.git.service;

import com.latm.git.repository.AlertRepository;
import com.latm.git.repository.LogRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class CleanupService {

    private static final long KEEP_LATEST = 5000;

    private final LogRepository logRepo;
    private final AlertRepository alertRepo;

    public CleanupService(LogRepository logRepo, AlertRepository alertRepo) {
        this.logRepo = logRepo;
        this.alertRepo = alertRepo;
    }

    @Scheduled(fixedRate = 60_000)   // har 1 minute mein
    public void cleanup() {
        logRepo.findTopByOrderByIdDesc()
                .ifPresent(l -> logRepo.deleteByIdLessThan(l.getId() - KEEP_LATEST));
        alertRepo.findTopByOrderByIdDesc()
                .ifPresent(a -> alertRepo.deleteByIdLessThan(a.getId() - KEEP_LATEST));
    }
}