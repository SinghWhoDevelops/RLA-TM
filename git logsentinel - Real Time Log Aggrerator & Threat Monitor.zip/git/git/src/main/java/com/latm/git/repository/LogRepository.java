package com.latm.git.repository;

import com.latm.git.model.LogLevel;
import com.latm.git.model.LogRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface LogRepository extends JpaRepository<LogRecord, Long> {
    List<LogRecord> findTop50ByOrderByIdDesc();
    long countByLevel(LogLevel level);
    Optional<LogRecord> findTopByOrderByIdDesc();

    @Transactional
    void deleteByIdLessThan(Long id);
}