package com.latm.git.model;

public enum LogLevel { INFO, WARN, ERROR }