package com.latm.git.controller;

import com.latm.git.model.AlertRecord;
import com.latm.git.model.LogLevel;
import com.latm.git.model.LogRecord;
import com.latm.git.repository.AlertRepository;
import com.latm.git.repository.LogRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {

    private final LogRepository logRepo;
    private final AlertRepository alertRepo;

    public ApiController(LogRepository logRepo, AlertRepository alertRepo) {
        this.logRepo = logRepo;
        this.alertRepo = alertRepo;
    }

    @GetMapping("/logs")
    public List<LogRecord> logs() {
        return logRepo.findTop50ByOrderByIdDesc();
    }

    @GetMapping("/alerts")
    public List<AlertRecord> alerts() {
        return alertRepo.findTop50ByOrderByIdDesc();
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("totalLogs", logRepo.count());
        s.put("info", logRepo.countByLevel(LogLevel.INFO));
        s.put("warn", logRepo.countByLevel(LogLevel.WARN));
        s.put("error", logRepo.countByLevel(LogLevel.ERROR));
        s.put("totalAlerts", alertRepo.count());
        s.put("critical", alertRepo.countBySeverity("CRITICAL"));
        s.put("high", alertRepo.countBySeverity("HIGH"));
        s.put("medium", alertRepo.countBySeverity("MEDIUM"));
        return s;
    }
}