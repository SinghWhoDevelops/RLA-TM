package com.latm.git.service;

import com.latm.git.model.Alert;
import com.latm.git.model.AlertRecord;
import com.latm.git.model.LogEvent;
import com.latm.git.model.LogRecord;
import com.latm.git.repository.AlertRepository;
import com.latm.git.repository.LogRepository;
import org.springframework.stereotype.Service;

@Service
public class StorageService {

    private final LogRepository logRepo;
    private final AlertRepository alertRepo;

    public StorageService(LogRepository logRepo, AlertRepository alertRepo) {
        this.logRepo = logRepo;
        this.alertRepo = alertRepo;
    }

    public void save(LogEvent event) {
        logRepo.save(new LogRecord(event));
    }

    public void save(Alert alert) {
        alertRepo.save(new AlertRecord(alert));
    }
}