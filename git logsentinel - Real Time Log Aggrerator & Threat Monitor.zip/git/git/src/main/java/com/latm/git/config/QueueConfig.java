package com.latm.git.config;

import com.latm.git.model.LogEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@Configuration
public class QueueConfig {
    @Bean
    public BlockingQueue<LogEvent> logQueue() {
        return new LinkedBlockingQueue<>(10_000);
    }
}