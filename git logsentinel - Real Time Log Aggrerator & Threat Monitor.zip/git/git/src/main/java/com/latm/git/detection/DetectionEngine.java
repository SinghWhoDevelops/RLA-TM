package com.latm.git.detection;

import com.latm.git.model.Alert;
import com.latm.git.model.LogEvent;
import com.latm.git.model.LogLevel;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class DetectionEngine {

    private static final int FAILED_LOGIN_THRESHOLD = 5;
    private static final Duration WINDOW = Duration.ofSeconds(5);

    private final Map<String, Deque<Instant>> failedLogins = new ConcurrentHashMap<>();

    public List<Alert> analyze(LogEvent event) {
        List<Alert> alerts = new ArrayList<>();

        // Rule 1: ERROR level logs
        if (event.level() == LogLevel.ERROR) {
            boolean sqli = event.message().contains("SQL Injection");
            alerts.add(new Alert(
                    event.timestamp(),
                    sqli ? "SQL_INJECTION" : "ERROR_EVENT",
                    sqli ? "CRITICAL" : "MEDIUM",
                    event.ip(),
                    event.message()));
        }

        // Rule 2: brute-force (5 sec mein 5 failed logins, same IP)
        if (event.message().contains("Failed login")) {
            Deque<Instant> window = failedLogins.computeIfAbsent(event.ip(), k -> new ArrayDeque<>());
            synchronized (window) {
                Instant now = event.timestamp();
                window.addLast(now);

                while (!window.isEmpty() && window.peekFirst().isBefore(now.minus(WINDOW))) {
                    window.pollFirst();
                }

                if (window.size() >= FAILED_LOGIN_THRESHOLD) {
                    alerts.add(new Alert(now, "BRUTE_FORCE", "HIGH", event.ip(),
                            window.size() + " failed logins in " + WINDOW.toSeconds() + " seconds"));
                    window.clear();
                }
            }
        }
        return alerts;
    }
}