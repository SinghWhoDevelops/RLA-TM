package com.latm.git.service;

import com.latm.git.model.Alert;
import com.latm.git.model.LogEvent;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class PushService {

    private final SimpMessagingTemplate template;

    public PushService(SimpMessagingTemplate template) {
        this.template = template;
    }

    public void pushLog(LogEvent e) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("timestamp", e.timestamp().toString());
        m.put("level", e.level().name());
        m.put("source", e.source());
        m.put("ip", e.ip());
        m.put("message", e.message());
        template.convertAndSend("/topic/logs", (Object) m);
    }

    public void pushAlert(Alert a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("timestamp", a.timestamp().toString());
        m.put("type", a.type());
        m.put("severity", a.severity());
        m.put("ip", a.ip());
        m.put("description", a.description());
        template.convertAndSend("/topic/alerts", (Object) m);
    }
}