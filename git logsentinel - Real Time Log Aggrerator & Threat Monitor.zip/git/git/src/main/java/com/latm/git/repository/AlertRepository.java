package com.latm.git.repository;

import com.latm.git.model.AlertRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface AlertRepository extends JpaRepository<AlertRecord, Long> {
    List<AlertRecord> findTop50ByOrderByIdDesc();
    long countBySeverity(String severity);
    Optional<AlertRecord> findTopByOrderByIdDesc();

    @Transactional
    void deleteByIdLessThan(Long id);
}