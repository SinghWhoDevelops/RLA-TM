package com.latm.git.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "alerts")
public class AlertRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_time")
    private Instant timestamp;

    @Column(name = "alert_type")
    private String type;

    private String severity;
    private String ip;
    private String description;

    protected AlertRecord() {}

    public AlertRecord(Alert a) {
        this.timestamp = a.timestamp();
        this.type = a.type();
        this.severity = a.severity();
        this.ip = a.ip();
        this.description = a.description();
    }

    public Long getId() { return id; }
    public Instant getTimestamp() { return timestamp; }
    public String getType() { return type; }
    public String getSeverity() { return severity; }
    public String getIp() { return ip; }
    public String getDescription() { return description; }
}