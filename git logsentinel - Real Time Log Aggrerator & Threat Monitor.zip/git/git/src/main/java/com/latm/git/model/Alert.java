package com.latm.git.model;

import java.time.Instant;

public record Alert(Instant timestamp, String type, String severity, String ip, String description) {}