package com.latm.git.model;

import java.time.Instant;

public record LogEvent(Instant timestamp, LogLevel level, String source, String ip, String message) {}