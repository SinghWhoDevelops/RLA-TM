package com.latm.git.service;

import com.latm.git.detection.DetectionEngine;
import com.latm.git.model.LogEvent;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.concurrent.BlockingQueue;

@Component
public class LogConsumer {

    private final BlockingQueue<LogEvent> queue;
    private final DetectionEngine engine;
    private final StorageService storage;
    private final PushService push;

    public LogConsumer(BlockingQueue<LogEvent> queue, DetectionEngine engine,
                       StorageService storage, PushService push) {
        this.queue = queue;
        this.engine = engine;
        this.storage = storage;
        this.push = push;
    }

    @PostConstruct
    public void start() {
        Thread t = new Thread(() -> {
            try {
                while (true) {
                    LogEvent event = queue.take();
                    storage.save(event);
                    push.pushLog(event);
                    engine.analyze(event).forEach(a -> {
                        storage.save(a);
                        push.pushAlert(a);
                        System.out.println("ALERT >>> " + a);
                    });
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "log-consumer");
        t.setDaemon(true);
        t.start();
    }
}