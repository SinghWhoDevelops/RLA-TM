package com.latm.git.generator;

import com.latm.git.model.LogEvent;
import com.latm.git.model.LogLevel;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class LogGenerator {

    private final BlockingQueue<LogEvent> queue;
    private Thread worker;

    private static final List<String> SOURCES = List.of("auth-service", "payment-api", "web-gateway", "db-proxy");
    private static final List<String> IPS = List.of("10.0.0.5", "10.0.0.8", "192.168.1.20", "203.0.113.7", "198.51.100.23");

    public LogGenerator(BlockingQueue<LogEvent> queue) {
        this.queue = queue;
    }

    @PostConstruct
    public void start() {
        worker = new Thread(this::run, "log-generator");
        worker.setDaemon(true);
        worker.start();
    }

    @PreDestroy
    public void stop() {
        if (worker != null) worker.interrupt();
    }

    @SuppressWarnings("BusyWait")
    private void run() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        try {
            while (!Thread.currentThread().isInterrupted()) {
                if (r.nextInt(100) < 3) {   // 3% chance: attack shuru
                    burst(r);
                }
                boolean accepted = queue.offer(nextEvent(r));
                if (!accepted) {
                    System.err.println("Queue full, log dropped");
                }
                Thread.sleep(r.nextInt(100, 500));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // naya method: ek IP se 6 failed logins, 300 ms ke gap par
    private void burst(ThreadLocalRandom r) throws InterruptedException {
        String attacker = IPS.get(r.nextInt(IPS.size()));
        for (int i = 0; i < 6; i++) {
            queue.offer(new LogEvent(Instant.now(), LogLevel.WARN, "auth-service", attacker, "Failed login attempt"));
            Thread.sleep(300);
        }
    }

    private LogEvent nextEvent(ThreadLocalRandom r) {
        String source = SOURCES.get(r.nextInt(SOURCES.size()));
        String ip = IPS.get(r.nextInt(IPS.size()));
        int roll = r.nextInt(100);

        if (roll < 60) return new LogEvent(Instant.now(), LogLevel.INFO, source, ip, "Request handled successfully");
        if (roll < 75) return new LogEvent(Instant.now(), LogLevel.WARN, source, ip, "Slow response detected");
        if (roll < 90) return new LogEvent(Instant.now(), LogLevel.WARN, "auth-service", ip, "Failed login attempt");
        if (roll < 95) return new LogEvent(Instant.now(), LogLevel.ERROR, "db-proxy", ip, "SQL Injection attempt detected");
        return new LogEvent(Instant.now(), LogLevel.ERROR, source, ip, "Unhandled exception in request pipeline");
    }
}