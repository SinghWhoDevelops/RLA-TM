package com.latm.git.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "logs")
public class LogRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_time")
    private Instant timestamp;

    @Enumerated(EnumType.STRING)
    @Column(name = "log_level")
    private LogLevel level;

    private String source;
    private String ip;
    private String message;

    protected LogRecord() {}

    public LogRecord(LogEvent e) {
        this.timestamp = e.timestamp();
        this.level = e.level();
        this.source = e.source();
        this.ip = e.ip();
        this.message = e.message();
    }

    public Long getId() { return id; }
    public Instant getTimestamp() { return timestamp; }
    public LogLevel getLevel() { return level; }
    public String getSource() { return source; }
    public String getIp() { return ip; }
    public String getMessage() { return message; }
}