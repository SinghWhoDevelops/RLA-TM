package com.latm.git.detection;

import com.latm.git.model.Alert;
import com.latm.git.model.LogEvent;
import com.latm.git.model.LogLevel;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DetectionEngineTest {

    private static final Instant T0 = Instant.parse("2026-01-01T00:00:00Z");
    private final DetectionEngine engine = new DetectionEngine();

    private LogEvent event(LogLevel level, String ip, String msg, long offsetMillis) {
        return new LogEvent(T0.plusMillis(offsetMillis), level, "auth-service", ip, msg);
    }

    @Test
    void infoLogCreatesNoAlert() {
        List<Alert> alerts = engine.analyze(event(LogLevel.INFO, "10.0.0.1", "Request handled successfully", 0));
        assertTrue(alerts.isEmpty());
    }

    @Test
    void sqlInjectionCreatesCriticalAlert() {
        List<Alert> alerts = engine.analyze(event(LogLevel.ERROR, "10.0.0.1", "SQL Injection attempt detected", 0));
        assertEquals(1, alerts.size());
        assertEquals("SQL_INJECTION", alerts.get(0).type());
        assertEquals("CRITICAL", alerts.get(0).severity());
    }

    @Test
    void genericErrorCreatesMediumAlert() {
        List<Alert> alerts = engine.analyze(event(LogLevel.ERROR, "10.0.0.1", "Unhandled exception", 0));
        assertEquals(1, alerts.size());
        assertEquals("MEDIUM", alerts.get(0).severity());
    }

    @Test
    void fiveFailedLoginsInsideWindowTriggerBruteForce() {
        for (int i = 0; i < 4; i++) {
            assertTrue(engine.analyze(event(LogLevel.WARN, "10.0.0.9", "Failed login attempt", i * 300L)).isEmpty());
        }
        List<Alert> alerts = engine.analyze(event(LogLevel.WARN, "10.0.0.9", "Failed login attempt", 1200));
        assertEquals(1, alerts.size());
        assertEquals("BRUTE_FORCE", alerts.get(0).type());
        assertEquals("HIGH", alerts.get(0).severity());
    }

    @Test
    void slowFailedLoginsDoNotTrigger() {
        for (int i = 0; i < 6; i++) {
            // 3 sec ke gap par, window (5 sec) mein kabhi 5 nahi aate
            assertTrue(engine.analyze(event(LogLevel.WARN, "10.0.0.9", "Failed login attempt", i * 3000L)).isEmpty());
        }
    }

    @Test
    void failedLoginsFromDifferentIpsAreNotCombined() {
        for (int i = 0; i < 6; i++) {
            String ip = (i % 2 == 0) ? "10.0.0.1" : "10.0.0.2";
            assertTrue(engine.analyze(event(LogLevel.WARN, ip, "Failed login attempt", i * 200L)).isEmpty());
        }
    }
}